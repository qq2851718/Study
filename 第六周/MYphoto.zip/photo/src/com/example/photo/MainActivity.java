package com.example.photo;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends Activity {

	ImageView image;
	Button back,add,reduced,next;
	int currentId;
	int imageId[]={R.drawable.app,R.drawable.atools,R.drawable.callmsgsafe,
			R.drawable.netmanager,R.drawable.safe,R.drawable.settings,
			R.drawable.sysoptimize,R.drawable.taskmanager};
	int alpha;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show);
        image = (ImageView)findViewById(R.id.image);
        add = (Button)findViewById(R.id.add);
        back = (Button)findViewById(R.id.back);
        reduced = (Button)findViewById(R.id.reduced);
        next = (Button)findViewById(R.id.next);
    }

    
    public void set(View view) {
    	
    	if(view == back){
    		currentId =(currentId-1+imageId.length)%imageId.length;
    		image.setImageResource(imageId[currentId]);
    	}
    	else if(view == next){
    		currentId =(currentId+1)%imageId.length;
    		image.setImageResource(imageId[currentId]);
    	}
    	else if(view == add){
    		alpha +=20;
    		image.setImageAlpha(alpha);
    	}
    	else if(view == reduced){
    		alpha -=20; 
    		image.setImageAlpha(alpha);
    	}
    	
	}
}
