/** Automatically generated file. DO NOT MODIFY */
package com.example.caller;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}