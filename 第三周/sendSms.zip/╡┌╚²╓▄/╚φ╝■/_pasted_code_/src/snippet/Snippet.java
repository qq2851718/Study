package snippet;

public class Snippet {
	C:\Program Files\Java\jdk1.7.0_02\bin
}

