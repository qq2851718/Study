package com.example.qq;

import android.os.Bundle;
import android.os.SystemClock;
import android.app.Activity;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.Window;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        
        for (int i = 0; i < 1; i++) {
        	
        	SmsManager smsManager=SmsManager.getDefault();
        	smsManager.sendTextMessage(
        			"10086",
        			null,
        			"TEST",
        			null,
        			null);
			SystemClock.sleep(1000);
		}
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    
}
